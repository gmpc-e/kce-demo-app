plugins {
  // keep empty at root
}

val groupProp = (findProperty("GROUP") as String?) ?: "com.elad.halacha"
val versionProp = (findProperty("VERSION_NAME") as String?) ?: "0.1.1-SNAPSHOT"

allprojects {
  group = groupProp
  version = versionProp
}
pluginManagement {
  repositories {
    google()
    gradlePluginPortal()
    mavenCentral()
    mavenLocal()
  }
}

dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories {
    google()
    mavenCentral()
    mavenLocal() // allow local snapshots if you ever publish the engine locally
  }
}

rootProject.name = "kce-demo-app"

// Android app module
include(":app")

// ★ Link the sibling engine repo as a composite build
includeBuild("../kosherjava-compute-engine")
package com.elad.kce.demo

import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime

// Cities from assets
data class City(
  val name: String,
  val lat: Double,
  val lon: Double,
  val elev: Double
)

// One row for the list
data class ZmanItem(
  val labelHe: String,
  val time: LocalTime
)

// What we render on screen
data class ComputeResultDemo(
  val profileName: String,
  val locationName: String,
  val date: String,
  val times: List<ZmanItem>
)

data class UiState(
  val loading: Boolean = false,
  val error: String? = null,
  val date: LocalDate = LocalDate.now(),
  val cities: List<City> = emptyList(),
  val selectedCityIdx: Int = 0,
  val profiles: List<EngineBridge.UiProfile> = emptyList(),
  val selectedProfileIdx: Int = 0,
  val result: ComputeResultDemo? = null,
  val shaahZmanit: Duration? = null
)
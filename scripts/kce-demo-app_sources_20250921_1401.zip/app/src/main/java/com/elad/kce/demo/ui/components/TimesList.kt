package com.elad.kce.demo.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.elad.kce.demo.ComputeResultDemo
import com.elad.kce.demo.ui.theme.PurplePrimary
import java.time.Duration

@Composable
fun TimesSection(
    result: ComputeResultDemo?,
    loading: Boolean,
    error: String?,
    shaahZmanit: Duration?,
    modifier: Modifier = Modifier
) {
    when {
        loading -> {
            Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                androidx.compose.material3.CircularProgressIndicator()
            }
        }
        error != null -> {
            ErrorCard(error)
        }
        result != null -> {
            ElevatedCard(modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // header row under the title
                    Text(
                        text = "${result.locationName}  •  ${result.date}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Divider()

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(result.times) { item ->
                            ZmanRow(
                                time = "%02d:%02d".format(item.time.hour, item.time.minute),
                                label = item.labelHe
                            )
                        }

                        item {
                            Spacer(Modifier.height(8.dp))
                            if (shaahZmanit != null) {
                                ShaahZmanitCard(shaahZmanit)
                            }
                        }
                    }
                }
            }
        }
        else -> {
            PlaceholderCard()
        }
    }
}

@Composable
private fun ZmanRow(time: String, label: String) {
    Surface(
        tonalElevation = 3.dp,
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // time (left) – purple + bold
            Text(
                time,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = PurplePrimary
            )
            // label (right)
            Text(label, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun ShaahZmanitCard(dur: Duration) {
    val mins = dur.toMinutes()
    val hh = (mins / 60).toInt()
    val mm = (mins % 60).toInt()
    // 1/60th of an hour:
    val dakaSeconds = dur.seconds / 60

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                "שעה זמנית - %02d:%02d שעות".format(hh, mm),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
            )
            Text("דקה זמנית - ${dakaSeconds} שניות")
        }
    }
}

@Composable
private fun ErrorCard(msg: String) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("שגיאה", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(6.dp))
            Text(msg)
        }
    }
}

@Composable
private fun PlaceholderCard() {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("בחר עיר ולוח כדי להציג זמנים", style = MaterialTheme.typography.titleMedium)
            Text("ניתן להשתמש בכפתורי התאריך או לבחור תאריך בלוח.")
        }
    }
}
package com.elad.kce.demo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.elad.kce.demo.ui.components.Chip
import com.elad.kce.demo.ui.components.CompactDropdown
import com.elad.kce.demo.ui.components.IconChip
import com.elad.kce.demo.ui.theme.KceTheme
import com.elad.kce.demo.ui.theme.PurplePrimary
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
  private val vm: MainViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        KceTheme {
          // kick off cities + profiles when composition starts
          LaunchedEffect(Unit) {
            vm.loadCitiesFromAssets(applicationContext)
            vm.refreshProfiles()
          }
          AppScreen(vm)
        }
      }
    }
  }
}

@Composable
fun AppScreen(vm: MainViewModel) {
  val state by vm.state
  val dateFmt = remember { DateTimeFormatter.ofPattern("yyyy-MM-dd") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.surface)
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {

    // Title (tap to force compute; doubles as a "refresh")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
      Text(
        text = state.result?.profileName ?: "זמנים יהודיים",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        color = PurplePrimary,
        modifier = Modifier.clickable { vm.compute() }
      )
    }

    // Date controls: ◀  היום  ▶
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      IconChip(text = "◀", onClick = vm::prevDay)
      Chip(text = "היום", onClick = vm::today)
      IconChip(text = "▶", onClick = vm::nextDay)
    }

    // Date text (no clock)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
      Text(
        text = dateFmt.format(state.date),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    // Selectors: Profile + City
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      CompactDropdown(
        label = state.profiles.getOrNull(state.selectedProfileIdx)?.displayName ?: "לוח",
        items = state.profiles.map { it.displayName },
        onSelect = { idx -> vm.selectProfile(idx) },
        modifier = Modifier.weight(1f)
      )
      CompactDropdown(
        label = state.cities.getOrNull(state.selectedCityIdx)?.name ?: "עיר",
        items = state.cities.map { it.name },
        onSelect = { idx -> vm.selectCity(idx) },
        modifier = Modifier.weight(1f)
      )
    }

    // Results
    when {
      state.loading -> {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
          CircularProgressIndicator()
        }
      }
      state.error != null -> {
        ErrorCard(state.error!!)
      }
      state.result != null -> {
        Text(
          text = "${state.result!!.locationName}  •  ${state.result!!.date}",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 24.dp)
        ) {
          items(state.result!!.times) { item ->
            ZmanRow(
              time = "%02d:%02d".format(item.time.hour, item.time.minute),
              label = item.labelHe
            )
          }
          item { ShaahZmanitCard(state) }
        }
      }
      else -> {
        PlaceholderCard()
      }
    }
  }
}

@Composable
fun ErrorCard(msg: String) {
  ElevatedCard(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
      Text("שגיאה", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
      Spacer(Modifier.height(6.dp))
      Text(msg)
    }
  }
}

@Composable
fun PlaceholderCard() {
  ElevatedCard(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
      Text("בחר עיר ולוח כדי להציג זמנים", style = MaterialTheme.typography.titleMedium)
      Text("השתמש בכפתורי התאריך או בחר פרופיל.")
    }
  }
}

@Composable
fun ZmanRow(time: String, label: String) {
  Surface(
    tonalElevation = 3.dp,
    shape = MaterialTheme.shapes.large,
    color = MaterialTheme.colorScheme.surfaceVariant,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      Modifier
        .padding(horizontal = 14.dp, vertical = 10.dp)
        .fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        time,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = PurplePrimary
      )
      Text(label, style = MaterialTheme.typography.bodyLarge)
    }
  }
}

@Composable
fun ShaahZmanitCard(state: UiState) {
  val dur = state.shaahZmanit ?: return
  val mins = dur.toMinutes()
  val hh = (mins / 60).toInt()
  val mm = (mins % 60).toInt()
  val dakaTotalSeconds = (dur.seconds / 60)
  ElevatedCard(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text(
        "שעה זמנית - %02d:%02d שעות".format(hh, mm),
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
      )
      Text("דקה זמנית - ${dakaTotalSeconds} שניות")
    }
  }
}
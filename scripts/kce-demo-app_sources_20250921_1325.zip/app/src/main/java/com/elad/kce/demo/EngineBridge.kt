package com.elad.kce.demo

import com.elad.halacha.profiles.api.GeoInput
import com.elad.halacha.profiles.api.ProfileComputeInput
import com.elad.halacha.profiles.api.ProfilesService
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.LocalTime
import android.util.Log
import com.elad.halacha.engine.model.ComputeResult
import java.time.Duration

object EngineBridge {

  data class UiProfile(val key: String, val displayName: String)

  private val svc: ProfilesService
    get() = EngineServices.profilesService

  private val ISO_DT: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME

  fun listProfiles(): List<UiProfile> {
    val entries = svc.listProfiles()
    return entries.map {
      val display = (it.labels?.he ?: it.displayName).ifBlank { it.key }
      UiProfile(key = it.key, displayName = display)
    }.sortedBy { it.displayName }
  }

  /** Best-effort derive שעה זמנית from sunrise/sunset if engine doesn't provide it directly. */
  fun deriveShaahZmanitOrNull(res: ComputeResult): Duration? {
    return try {
      val sunrise = res.times.firstOrNull { it.id.contains("sunrise", ignoreCase = true) || it.labelHe.contains("זריחה") }?.time
      val sunset  = res.times.firstOrNull  { it.id.contains("sunset",  ignoreCase = true) || it.labelHe.contains("שקיעה") }?.time
      if (sunrise != null && sunset != null) {
        val dayMinutes = Duration.between(sunrise, sunset).toMinutes()
        Duration.ofMinutes(dayMinutes / 12)
      } else null
    } catch (t: Throwable) {
      Log.w("KCE", "deriveShaahZmanitOrNull: ${t.message}")
      null
    }
  }
}

  fun computeProfile(
    profileKey: String,
    date: LocalDate,
    lat: Double,
    lon: Double,
    elev: Double,
    tz: String
  ): ComputeResultDemo {
    val input = ProfileComputeInput(
      dateIso = date.toString(),
      geo = GeoInput(lat = lat, lon = lon, elev = elev, tz = tz)
    )
    val res = svc.computeProfile(profileKey, input)

    val zone = ZoneId.of(tz)

    val items = res.results.mapNotNull { r ->
      val labelHe = r.label?.he ?: r.label?.en ?: r.id
      val localStr: String? = r.local
      val instStr: String? = r.instant

      val localTime: LocalTime? = when {
        !localStr.isNullOrBlank() -> {
          val cleaned = localStr.replace(Regex("\\[.*\\]\$"), "")
          OffsetDateTime.parse(cleaned, ISO_DT).toLocalTime()
        }
        !instStr.isNullOrBlank() -> {
          java.time.Instant.parse(instStr).atZone(zone).toLocalTime()
        }
        else -> null
      }?.roundNoSecondsUp30()

      localTime?.let { ZmanItem(labelHe = labelHe, time = it) }
    }

    val header = res.profile.labels?.he
      ?: res.profile.displayName.ifBlank { res.profile.key }

    return ComputeResultDemo(
      profileName = header,
      locationName = "",            // filled by caller with city.name
      date = LocalDate.parse(input.dateIso),
      times = items
    )
  }
}
package com.elad.kce.demo.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.elad.kce.demo.City
import com.elad.kce.demo.EngineBridge
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ControlsBar(
    date: LocalDate,
    onDateChange: (LocalDate) -> Unit,
    onPrevDay: () -> Unit,
    onToday: () -> Unit,
    onNextDay: () -> Unit,
    cities: List<City>,
    selectedCityIdx: Int,
    onSelectCity: (Int) -> Unit,
    profiles: List<EngineBridge.UiProfile>,
    selectedProfileIdx: Int,
    onSelectProfile: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showDatePicker by remember { mutableStateOf(false) }
    val timeFmt = remember { DateTimeFormatter.ofPattern("HH:mm:ss") }
    var now by remember { mutableStateOf(java.time.LocalTime.now()) }

    // live clock tick
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = java.time.LocalTime.now()
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Row 1: Date controls + live clock
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(onClick = onToday) { Text("היום", fontWeight = FontWeight.SemiBold) }
            OutlinedButton(onClick = onPrevDay) { Text("אתמול") }
            OutlinedButton(onClick = { showDatePicker = true }) { Text("בחר תאריך") }
            OutlinedButton(onClick = onNextDay) { Text("מחר") }

            Spacer(Modifier.weight(1f))

            Text(
                text = "${date}  •  ${timeFmt.format(now)}"
            )
        }

        // Row 2: Profile + City dropdowns
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CompactDropdown(
                label = profiles.getOrNull(selectedProfileIdx)?.displayName ?: "לוח",
                items = profiles.map { it.displayName },
                onSelect = onSelectProfile,
                modifier = Modifier.weight(1f)
            )
            CompactDropdown(
                label = cities.getOrNull(selectedCityIdx)?.name ?: "עיר",
                items = cities.map { it.name },
                onSelect = onSelectCity,
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (showDatePicker) {
        val initialMillis = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val dateState = androidx.compose.material3.rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val millis = dateState.selectedDateMillis
                    if (millis != null) {
                        val picked = java.time.Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
                        onDateChange(picked)
                    }
                    showDatePicker = false
                }) { Text("בחר") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("בטל") } }
        ) {
            DatePicker(state = dateState)
        }
    }
}

@Composable
fun CompactDropdown(
    label: String,
    items: List<String>,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(label)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            items.forEachIndexed { idx, s ->
                DropdownMenuItem(
                    text = { Text(s) },
                    onClick = { expanded = false; onSelect(idx) }
                )
            }
        }
    }
}
@Composable
fun Chip(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(modifier = modifier, onClick = onClick) {
        Text(text)
    }
}

@Composable
fun IconChip(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(modifier = modifier, onClick = onClick) {
        Text(text)
    }
}
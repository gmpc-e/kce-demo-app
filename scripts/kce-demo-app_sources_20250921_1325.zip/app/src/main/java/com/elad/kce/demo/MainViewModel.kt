package com.elad.kce.demo

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.elad.kce.demo.data.AssetCities
import com.elad.kce.demo.EngineBridge.UiProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.Duration

data class City(val name: String, val lat: Double, val lon: Double, val elev: Double)

data class ComputeResultDemo(
  val profileName: String,
  val locationName: String,
  val date: String,
  val times: List<ZmanItem>
)

data class ZmanItem(val labelHe: String, val time: java.time.LocalTime)

data class UiState(
  val loading: Boolean = false,
  val error: String? = null,
  val date: LocalDate = LocalDate.now(),
  val cities: List<City> = emptyList(),
  val selectedCityIdx: Int = 0,
  val profiles: List<UiProfile> = emptyList(),
  val selectedProfileIdx: Int = 0,
  val result: ComputeResultDemo? = null,
  val shaahZmanit: Duration? = null
)

class MainViewModel : ViewModel() {

  private val TAG = "KCE"
  private val _state = androidx.compose.runtime.mutableStateOf(UiState())
  val state: androidx.compose.runtime.State<UiState> = _state

  // —— lifecycle-ish helpers ——
  fun loadCitiesFromAssets(context: Context) {
    viewModelScope.launch(Dispatchers.IO) {
      val cities = AssetCities.load(context)
      withContext(Dispatchers.Main) {
        _state.value = _state.value.copy(cities = cities, selectedCityIdx = 0)
        // compute if we already have profiles
        if (_state.value.profiles.isNotEmpty()) compute()
      }
    }
  }

  suspend fun refreshProfiles() {
    Log.d(TAG, "refreshProfiles(): listing profiles from engine store")
    _state.value = _state.value.copy(loading = true, error = null)
    try {
      val profiles = withContext(Dispatchers.IO) {
        // Use the engine side API (store/service)
        // We lean on EngineBridge to keep wiring minimal.
        EngineBridge.listProfiles().also {
          Log.d(TAG, "EngineBridge.listProfiles() -> ${it.size} profiles")
          it.forEach { p -> Log.d(TAG, "profile key=${p.key} name=${p.displayName}") }
        }
      }
      _state.value = _state.value.copy(profiles = profiles, selectedProfileIdx = 0)
      // trigger compute when profiles are ready and we have at least one city
      if (_state.value.cities.isNotEmpty() && profiles.isNotEmpty()) {
        compute()
      } else {
        _state.value = _state.value.copy(loading = false)
      }
    } catch (t: Throwable) {
      Log.e(TAG, "refreshProfiles() failed", t)
      _state.value = _state.value.copy(loading = false, error = t.message ?: "Profiles error")
    }
  }

  fun setDate(d: LocalDate) {
    _state.value = _state.value.copy(date = d)
    compute()
  }
  fun today() = setDate(LocalDate.now())
  fun nextDay() = setDate(_state.value.date.plusDays(1))
  fun prevDay() = setDate(_state.value.date.minusDays(1))

  fun selectCity(idx: Int) {
    _state.value = _state.value.copy(selectedCityIdx = idx)
    compute()
  }

  fun selectProfile(idx: Int) {
    _state.value = _state.value.copy(selectedProfileIdx = idx)
    compute()
  }

  fun compute() {
    val st = _state.value
    if (st.cities.isEmpty() || st.profiles.isEmpty()) {
      Log.d(TAG, "compute(): waiting for cities=${st.cities.size} profiles=${st.profiles.size}")
      _state.value = _state.value.copy(loading = false)
      return
    }
    val city = st.cities[st.selectedCityIdx]
    val profile = st.profiles[st.selectedProfileIdx]
    Log.d(TAG, "compute(): date=${st.date} city=${city.name} lat=${city.lat}, lon=${city.lon}, elev=${city.elev} profile=${profile.displayName}(${profile.key})")
    _state.value = _state.value.copy(loading = true, error = null)

    viewModelScope.launch(Dispatchers.IO) {
      try {
        val res = EngineBridge.computeByKey(
          key = profile.key,
          date = st.date,
          lat = city.lat,
          lon = city.lon,
          elev = city.elev,
          tz = "Asia/Jerusalem",
          lang = "he"
        )
        // Map to UI model
        val ui = ComputeResultDemo(
          profileName = res.profileName ?: profile.displayName,
          locationName = city.name,
          date = res.date.toString(),
          times = res.times.map { ZmanItem(it.labelHe, it.time) }
        )
        // derive shaah zmanit (best-effort) if you expose it from engine; else compute from sunrise/sunset
        val shaah = EngineBridge.deriveShaahZmanitOrNull(res)

        withContext(Dispatchers.Main) {
          _state.value = _state.value.copy(result = ui, shaahZmanit = shaah, loading = false, error = null)
        }
      } catch (t: Throwable) {
        Log.e(TAG, "compute() failed", t)
        withContext(Dispatchers.Main) {
          _state.value = _state.value.copy(loading = false, error = t.message ?: "Compute error")
        }
      }
    }
  }
}
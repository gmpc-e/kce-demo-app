package com.elad.kce.demo

import com.elad.halacha.profiles.api.ProfilesService
import com.elad.halacha.engine.profiles.ProfilesServiceImpl

/** Simple, app-local DI */
object EngineServices {
    // If the engine needs init in the future, do it here.
    val profilesService: ProfilesService by lazy { ProfilesServiceImpl() }
}
package com.elad.kce.demo

import com.elad.halacha.profiles.api.Labels
import com.elad.halacha.profiles.api.ProfilesService
import com.elad.halacha.profiles.api.ProfileComputeInput
import com.elad.halacha.profiles.api.GeoInput
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalTime
import java.time.ZoneId

object EngineBridge {

  data class UiProfile(val key: String, val displayName: String)

  private val ISO_DT: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME

  private val svc: ProfilesService
    get() = EngineServices.profilesService

  /** 1) List profiles from engine store (classpath). */
  fun listProfiles(): List<UiProfile> {
    val list = svc.listProfiles()
    return list.map {
      val he = it.labels?.he
      UiProfile(
        key = it.key,
        displayName = (he ?: it.displayName).ifBlank { it.key }
      )
    }.sortedBy { it.displayName }
  }

  /** 2) Compute selected profile and map to UI items (Hebrew label + rounded HH:mm). */
  fun computeProfile(
    profileKey: String,
    dateIso: String,   // "YYYY-MM-DD"
    lat: Double,
    lon: Double,
    elev: Double,
    tz: String = "Asia/Jerusalem"
  ): ComputeResultDemo {
    val input = ProfileComputeInput(
      dateIso = dateIso,
      geo = GeoInput(lat = lat, lon = lon, elev = elev, tz = tz)
    )

    val res = svc.computeProfile(profileKey, input)

    val zone = ZoneId.of(tz)

    val items: List<ZmanItem> = res.results.mapNotNull { item ->
      val labelHe = item.label?.he
        ?: item.label?.en
        ?: item.id

      // Prefer `local` (already tz’d). If null, try `instant`→local zone.
      val localTime: LocalTime? = when {
        !item.local.isNullOrBlank() -> {
          // item.local may include “[Asia/Jerusalem]”; strip suffix if present
          val cleaned = item.local.replace(Regex("\\[.*\\]\$"), "")
          OffsetDateTime.parse(cleaned, ISO_DT).toLocalTime()
        }
        !item.instant.isNullOrBlank() -> {
          val inst = java.time.Instant.parse(item.instant)
          inst.atZone(zone).toLocalTime()
        }
        else -> null
      }?.roundNoSecondsUp30()

      localTime?.let { ZmanItem(labelHe = labelHe, time = it) }
    }

    val header = res.profile.labels?.he ?: res.profile.displayName.ifBlank { res.profile.key }

    return ComputeResultDemo(
      profileName = header,
      locationName = "",         // set by caller
      date = java.time.LocalDate.parse(dateIso),
      times = items
    )
  }
}

/** Presentation rounding: hide seconds; if sec > 30, round minute up. */
fun LocalTime.roundNoSecondsUp30(): LocalTime {
  val plus = if (this.second > 30) 1 else 0
  return this.withSecond(0).withNano(0).plusMinutes(plus.toLong())
}
package com.elad.kce.demo

import android.util.Log
import com.elad.halacha.engine.profiles.ProfilesServiceImpl
import com.elad.halacha.profiles.api.GeoInput
import com.elad.halacha.profiles.api.ProfileComputeInput
import com.elad.halacha.profiles.api.ProfileComputeItem
import java.time.*

/**
 * Adapter around the engine ProfilesServiceImpl.
 * NOTE: Keep ONLY Engine-specific types here to avoid model clashes.
 */
object EngineBridge {

  private const val TAG = "KCE"
  private val svc: ProfilesServiceImpl by lazy { ProfilesServiceImpl() }

  data class UiProfile(val key: String, val displayName: String)

  data class EngineItem(
    val id: String,
    val labelHe: String,
    val time: LocalTime? // rounded (seconds hidden), null if not computable
  )

  data class EngineResult(
    val profileName: String?,
    val date: LocalDate,
    val times: List<EngineItem>
  )

  /** List profiles exposed by engine classpath store. */
  fun listProfiles(): List<UiProfile> {
    return runCatching {
      val raw = svc.listProfiles()
      Log.d(TAG, "listProfiles(): engine returned ${raw.size} profiles")
      raw.forEachIndexed { i, p -> Log.d(TAG, "profile[$i]: key=${p.key}, name=${p.displayName}") }
      raw.map { UiProfile(it.key, it.displayName) }
    }.onFailure { t ->
      Log.e(TAG, "listProfiles() failed", t)
    }.getOrDefault(emptyList())
  }

  /** Compute a stored profile by key. */
  fun computeByKey(
    key: String,
    date: LocalDate,
    lat: Double,
    lon: Double,
    elev: Double?,
    tz: String,
    lang: String = "he"
  ): EngineResult {
    Log.d(TAG, "computeByKey(): key=$key date=$date geo=($lat,$lon,$elev) tz=$tz")
    val input = ProfileComputeInput(
      dateIso = date.toString(),
      geo = GeoInput(lat = lat, lon = lon, elev = elev ?: 0.0, tz = tz)
    )
    val resp = runCatching { svc.computeProfile(key, input) }
      .onFailure { Log.e(TAG, "computeProfile() threw", it) }
      .getOrThrow()

    Log.d(TAG, "computeByKey(): results=${resp.results.size}, warnings=${resp.warnings.size}")
    resp.warnings.forEach { w ->
      Log.w(TAG, "warning path=${w.path} code=${w.code} msg=${w.message}")
    }

    val zone = ZoneId.of(resp.input.geo.tz)
    val items = resp.results.map { r ->
      val labelHe = r.label?.he ?: r.label?.en ?: r.id
      Log.v(TAG, "result id=${r.id} labelHe=$labelHe local=${r.local} instant=${r.instant}")
      EngineItem(
        id = r.id,
        labelHe = labelHe,
        time = pickLocalTimeRounded(r, zone)
      )
    }

    val outDate = runCatching { LocalDate.parse(resp.input.dateIso) }
      .getOrElse { firstTemporalDate(resp.results, zone) ?: date }

    return EngineResult(
      profileName = resp.profile.displayName,
      date = outDate,
      times = items
    )
  }

  /** Convert EngineResult → UI result. */
  fun toUiResult(
    res: EngineResult,
    locationName: String,
    fallbackProfileName: String
  ): ComputeResultDemo {
    val uiTimes = res.times.mapNotNull { it.time?.let { t -> ZmanItem(it.labelHe, t) } }
    return ComputeResultDemo(
      profileName = res.profileName ?: fallbackProfileName,
      locationName = locationName,
      date = res.date.toString(),
      times = uiTimes
    )
  }

  /** Derive שעה זמנית if sunrise/sunset exists. */
  fun deriveShaahZmanitOrNull(res: EngineResult): Duration? {
    val sunrise = res.times.firstOrNull { it.id.contains("sunrise", true) || it.labelHe.contains("זריחה") }?.time
    val sunset  = res.times.firstOrNull { it.id.contains("sunset", true)  || it.labelHe.contains("שקיעה") }?.time
    if (sunrise != null && sunset != null) {
      val mins = Duration.between(sunrise, sunset).toMinutes()
      if (mins > 0) return Duration.ofMinutes(maxOf(1, (mins / 12)))
    }
    return null
  }

  // ————— internals —————

  private fun LocalTime.roundNoSecondsUp30(): LocalTime {
    val plusMin = if (second > 30) 1L else 0L
    return withSecond(0).withNano(0).plusMinutes(plusMin)
  }

  private fun pickLocalTimeRounded(r: ProfileComputeItem, zone: ZoneId): LocalTime? {
    r.instant?.let { s ->
      return runCatching { Instant.parse(s).atZone(zone).toLocalTime().roundNoSecondsUp30() }.getOrNull()
    }
    r.local?.let { s ->
      runCatching { OffsetDateTime.parse(s).toLocalTime().roundNoSecondsUp30() }.getOrNull()?.let { return it }
      runCatching { ZonedDateTime.parse(s).withZoneSameInstant(zone).toLocalTime().roundNoSecondsUp30() }.getOrNull()?.let { return it }
    }
    return null
  }

  private fun firstTemporalDate(items: List<ProfileComputeItem>, zone: ZoneId): LocalDate? {
    items.firstOrNull { it.instant != null }?.instant?.let {
      return runCatching { Instant.parse(it).atZone(zone).toLocalDate() }.getOrNull()
    }
    items.firstOrNull { it.local != null }?.local?.let {
      runCatching { OffsetDateTime.parse(it).toLocalDate() }.getOrNull()?.let { d -> return d }
      runCatching { ZonedDateTime.parse(it).withZoneSameInstant(zone).toLocalDate() }.getOrNull()?.let { d -> return d }
    }
    return null
  }
}